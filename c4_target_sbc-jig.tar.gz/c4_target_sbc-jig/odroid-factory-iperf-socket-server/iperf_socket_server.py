#!/usr/bin/env python3
#
# iperf3 supervisor of the external server
#
# You need the following pip packages
# - asyncio
#

from shutil import which
import sys
import subprocess
import asyncio


TCP_ECHO_SERVER_IP = '0.0.0.0'
TCP_ECHO_SERVER_PORT = 8888
which_iperf3 = None
iperf3_proc = None


def is_iperf3_exist():
    global which_iperf3

    which_iperf3 = which('iperf3')
    if which_iperf3 is None:
        return False
    else:
        return True

async def handle_tcp_echo(reader, writer):
    data = await reader.read(100)

    message = data.decode()
    addr = writer.get_extra_info('peername')
    print(f'Received "{message}" from {addr}')

    if 'iperf' in message:
        if 'start' in message:
            asyncio.ensure_future(stop_iperf())
            asyncio.ensure_future(start_iperf())
        elif 'stop' in message:
            asyncio.ensure_future(stop_iperf())
        else:
            print('Unknown command.')
    writer.close()

async def run_performance():
    try:
        cmd = 'service cpufrequtils restart'
        proc = await asyncio.create_subprocess_shell(cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await proc.communicate()

        stdout = stdout.decode('utf-8')
        print(stdout, stderr)
        if 'error' in stdout:
            print(stdout)

    except Exception as err:
        print(f'\t{err}')


async def start_iperf():
    global iperf3_proc
    global which_iperf3

    try:
        if iperf3_proc is None:
            iperf3_proc = await asyncio.create_subprocess_exec(
                which_iperf3, '-s',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE)            
            stdout, stderr = await iperf3_proc.communicate()

            stdout = stdout.decode('utf-8')
            if 'error' in stdout:
                print(stdout)

    except Exception as err:
            print(f'Error on line {sys.exc_info()[-1].tb_lineno}', end='\n')
            print(f'\t{err}')

async def stop_iperf():
    global iperf3_proc

    try:
        if iperf3_proc is not None:
            iperf3_proc.terminate()
            iperf3_proc = None
    except Exception as err:
            print(f'Error on line {sys.exc_info()[-1].tb_lineno}', end='\n')
            print(f'\t{err}')

if __name__ == '__main__':
    if is_iperf3_exist():
        loop = asyncio.get_event_loop()

        mode = loop.run_until_complete(run_performance())
        server_coro = asyncio.start_server(
            handle_tcp_echo, TCP_ECHO_SERVER_IP, TCP_ECHO_SERVER_PORT, loop=loop)
        server = loop.run_until_complete(server_coro)

        print('Serving on {}'.format(server.sockets[0].getsockname()))
        try:
            loop.run_forever()
        except KeyboardInterrupt:
            print('Keyboard interrupt occured!')
            print('Program will be closed.')
            pass
        
        server.close()
        loop.run_until_complete(server.wait_closed())
        loop.close()

    else:
        print('iperf3 doesn not exist. Please install that using "apt install iperf3"')
