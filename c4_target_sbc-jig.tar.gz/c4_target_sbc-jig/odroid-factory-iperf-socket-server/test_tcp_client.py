from time import sleep
import asyncio


async def tcp_echo_client(message, loop):
    reader, writer = await asyncio.open_connection('127.0.0.1', 8888,
                                                   loop=loop)

    print('Send: %r' % message)
    writer.write(message.encode())
    writer.close()


msg_iperf_start = 'request,iperf,start'
msg_iperf_stop = 'request,iperf,stop'

loop = asyncio.get_event_loop()

loop.run_until_complete(tcp_echo_client(msg_iperf_start, loop))
sleep(5)
loop.run_until_complete(tcp_echo_client(msg_iperf_stop, loop))

loop.close()
