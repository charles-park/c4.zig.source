# ODROID-FACTORY iperf3 Management Socket Server

This script opens a socket server to start/stop iperf3 program by the TCP echoing message.

It opens simple TCP echo server on **0.0.0.0:8888**.

## Installation

Install necessary pacakages.

```bash
sudo apt install python3 python3-dev python3-pip iperf3 screen cpufrequtils git
```

Clone (copy) this repository.

```bash
sudo git clone https://github.com/joshua-yang/odroid-factory-iperf-socket-server /root/odroid-factory-iperf-socket-server
# Or just copy its contents
```

Set cpufrequtils defaults.

```bash
cd /root/odroid-factory-iperf-socket-server
sudo cp ./cpufrequtils /etc/default
```

Enable service file.

```bash
cd /root/odroid-factory-iperf-socket-server
sudo cp ./iperf.service /etc/systemd/system/
sudo systemctl enable iperf
```

Reboot.

```bash
reboot
```

Check if it works.

```bash
ss -antp | grep 8888

# results
LISTEN   0         100                 0.0.0.0:8888             0.0.0.0:*        users:(("python3",pid=512,fd=6))
```

## How to make it use static IP

If the server device uses Ubuntu 18.04 or above, you should modify the netplan configuration file.

```bash
sudo vi /etc/netplan/static.conf
```

Copy the following contents.

```bash
network:
  version: 2
  renderer: networkd
  ethernets:
    eth0:
      dhcp4: no
      dhcp6: no
      addresses: [192.168.0.2/24]
      gateway4: 192.168.0.1
      nameservers:
        addresses: [8.8.8.8, 8.8.4.4]
```

Apply the new settings.

```bash
netplan apply
```

Or just reboot.

```bash
reboot
```

Check if it works.

```bash
ip addr show eth0

# results
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether 00:1e:06:31:fe:2d brd ff:ff:ff:ff:ff:ff
    inet 192.168.0.2/24 brd 192.168.0.255 scope global eth0
       valid_lft forever preferred_lft forever
    inet6 fe80::21e:6ff:fe31:fe2d/64 scope link
       valid_lft forever preferred_lft forever
```
