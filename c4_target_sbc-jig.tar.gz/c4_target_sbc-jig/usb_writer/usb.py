from constants import *
import asyncio
from asyncio import ensure_future as asyncef
import os
from gpio import GPIO

class USB():
    def __init__(self, node=None):
        self.node = node
        self.has_hub = None

    async def _scan_hub(self):
        cmd="lsusb | grep 2109 | awk '{print $6}'"
        proc = await asyncio.create_subprocess_shell(cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await proc.communicate()
        if stderr != b'':
            print(stderr)
        print(stdout)
        count = stdout.count(b'2109')
        self.has_hub = count
        return count

    async def reset_hub(self):
        if not os.path.exists(PATH_RESET_USB):
            return -1

        cmd = f"echo reset > {PATH_RESET_USB}"
        proc = await asyncio.create_subprocess_shell(cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await proc.communicate()
        if stderr != b'':
            print(stderr)
        print(stdout, stderr)

    async def scan_hub(self):
        result = await self._scan_hub()
        return result

    async def read_fw(self):
        cmd="usb-devices | grep Rev | grep 2109 | grep 817 | awk '{print $4}' | sed \"s/Rev=//g\""
        proc = await asyncio.create_subprocess_shell(cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await proc.communicate()
        if stderr != b'':
            print(stderr)
        ver = stdout.decode('utf-8').split()
        if len(ver) > 1:
            return ver[0]
        return ver

    async def write_fw(self):
        cmd="./upgrade_hub_arm64 -vid=2109 -pid=0817 -script=\"./VL817_Q7_9033.bin\""
        proc = await asyncio.create_subprocess_shell(cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await proc.communicate()
        if stderr != b'':
            print(stderr)
        ver = stdout.decode('utf-8').split()
        if len(ver) > 1:
            return ver[0]
        return ver

    async def wait_for_func(self, func):
        count = 0
        while count < 5:
            result = await func()
            if result == 2:
                return 0
            count += 1
            await asyncio.sleep(1)

    def led_error(self, gpio):
        #gpio.led.set_value(0)
        gpio.error()

    async def led_writing(self, gpio):
        while True:
            try:
                gpio.led.set_value(0)
                await asyncio.sleep(0.05)
                gpio.led.set_value(1)
                await asyncio.sleep(0.05)
            except asyncio.CancelledError:
                raise

    async def led_okay(self, gpio):
        while True:
            gpio.led.set_value(0)
            await asyncio.sleep(0.5)
            gpio.led.set_value(1)
            await asyncio.sleep(0.5)

async def main():
    gpio = GPIO()
    usb = USB()
    if await usb.wait_for_func(usb.scan_hub) != 0:
        "led error"
        usb.led_error(gpio)
    if await usb.read_fw() != "90.33":
        task_writing = asyncef(usb.led_writing(gpio))
        "led writing"
        task = await usb.write_fw()
        try:
            task_writing.cancel()
            await task_writing
        except asyncio.CancelledError:
            pass

        await usb.reset_hub()
        if await usb.wait_for_func(usb.scan_hub) != 0:
            "led error"
            usb.led_error(gpio)
        if await usb.read_fw() != "90.33":
            "led error"
            usb.led_error(gpio)
        else:
            "led okay"
            await usb.led_okay(gpio)
    else:
        "led okay"
        await usb.led_okay(gpio)

if __name__ == "__main__":
    asyncio.run(main())
