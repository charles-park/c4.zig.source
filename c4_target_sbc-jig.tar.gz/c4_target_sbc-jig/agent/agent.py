from uart import Uart
from adc import ADC
from odroid_factory_api import API_MANAGER
from utils.log import init_logger
import asyncio
from asyncio import ensure_future as asyncef
from board import C4
from copy import deepcopy
import sys, os, time

LOG = init_logger('', testing_mode='info')

from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.stacklayout import StackLayout
from kivy.app import App
from kivy.config import Config
from kivy.properties import ObjectProperty


Config.set('graphics', 'fullscreen', 'fake')
Config.set('graphics', 'width', '1024')
Config.set('graphics', 'height', '600')

os.environ['DISPLAY'] = ":0.0"

USB_R_U = '1.2'
USB_R_D = '1.3'

UART_IPERF_EXTERNAL_HOST_MAP = {
        USB_R_U: '192.168.0.200',
        USB_R_D: '192.168.0.200',
}

class Component():
    def __init__(self):
        self.req = None
        self.ack = None
        self.ret = None
        self.seq = None
        self.value = None
        self.okay = None
        self.update = None

class Task():
    def __init__(self, func):
        self.func = func
        self.id = None

    async def run(self):
        if await self.cancelled() == 0:
            self.id = asyncef(self.func())

    async def cancelled(self):
        try:
            if type(self.id) != asyncio.Task:
                return 0
            if self.id.cancel():
                await self.id
            return 0
        except asyncio.CancelledError:
            if self.id.cancelled():
                LOG.info('cancelled')
                return 0
        except Exception as e:
            print(e)

class Channel(StackLayout):
    name = ObjectProperty(None)
    onoff = ObjectProperty(None)
    ipaddr = ObjectProperty(None)
    eth_speed = ObjectProperty(None)
    mac = ObjectProperty(None)
    usb_otg = ObjectProperty(None)
    gpio = ObjectProperty(None)
    pb_gpio = ObjectProperty(None)
    iperf = ObjectProperty(None)
    pb_iperf = ObjectProperty(None)

    usb3_0 = ObjectProperty(None)
    usb3_1 = ObjectProperty(None)
    usb3_2 = ObjectProperty(None)
    usb3_3 = ObjectProperty(None)
    usb3_fw = ObjectProperty(None)

    led_sys = ObjectProperty(None)
    led_eth = ObjectProperty(None)
    edid = ObjectProperty(None)
    ir = ObjectProperty(None)
    finish = ObjectProperty(None)

    def __init__(self, **kwargs):
        self.agent = None
        self.items = None
        super(Channel, self).__init__(**kwargs)

    def init(self, agent):
        self.agent = agent
        self.items = self.agent.items
        self.items_gpio = self.agent.items_gpio
    def clear(self):
        self.ipaddr.text = "None"
        self.ipaddr.color = (1, 1, 1, 1)
        self.eth_speed.text = "None"
        self.eth_speed.color = (1, 1, 1, 1)
        self.mac.text = "None"
        self.mac.color = (1, 1, 1, 1)
        self.usb_otg.text = "None"
        self.usb_otg.color = (1, 1, 1, 1)
        self.gpio.text = "None"
        self.gpio.color = (1, 1, 1, 1)
        self.pb_gpio.value = 0

        self.iperf.text = "None"
        self.iperf.color = (1, 1, 1, 1)
        self.pb_iperf.value = 0

        self.usb3_0.text = "None"
        self.usb3_1.text = "None"
        self.usb3_2.text = "None"
        self.usb3_3.text = "None"
        self.usb3_0.color = (1, 1, 1, 1)
        self.usb3_1.color = (1, 1, 1, 1)
        self.usb3_2.color = (1, 1, 1, 1)
        self.usb3_3.color = (1, 1, 1, 1)

        self.usb3_fw.text = "None"
        self.usb3_fw.color = (1, 1, 1, 1)

        self.led_sys.color = (1, 1, 1, 1)
        self.led_eth.color = (1, 1, 1, 1)
        self.edid.color = (1, 1, 1, 1)
        self.ir.color = (1, 1, 1, 1)
        self.finish.color = (1, 1, 1, 1)

    def update(self):
        if self.agent.flag_ui_init == 1:
            self.agent.flag_ui_init = 0
            self.clear()
        if self.agent.power_on == 1:
            self.onoff.text = 'ON'
            self.onoff.color = (0, 1, 0, 0.3)
        else:
            self.onoff.text = 'OFF'
            self.onoff.color = (1, 0, 0, 0.3)

        if self.items['ipaddr'].ret != None:
            self.ipaddr.text = self.items['ipaddr'].value
            if self.items['ipaddr'].okay == 1:
                self.ipaddr.color = (0, 1, 0, 0.3)

        if self.items['eth_speed'].ret != None:
            self.eth_speed.text = self.items['eth_speed'].value
            if self.items['eth_speed'].okay == 1:
                self.eth_speed.color = (0, 1, 0, 0.3)

        if self.items['uuid'].okay != None and self.items['write_uuid'].okay != None:
            if self.items['uuid'].okay == 1:
                self.mac.text = self.items['uuid'].value[-12:]
                self.mac.color = (0, 0, 1, 0.3)
            else:
                if self.items['write_uuid'].okay == 1:
                    self.mac.text = self.items['write_uuid'].value[-12:]
                    self.mac.color = (0, 1, 0, 0.3)
                else:
                    self.mac.text = "ERROR"
                    self.mac.color = (1, 0, 0, 0.3)

        if self.items['otg_speed'].okay != None:
            if type(self.items['otg_speed'].value) != str:
                self.usb_otg.text = "ERROR"
                self.usb_otg.color = (1, 0, 0, 0.3)
            else:
                self.usb_otg.text = self.items['otg_speed'].value
                if self.items['otg_speed'].okay == 1:
                    self.usb_otg.color = (0, 1, 0, 0.3)
                else:
                    self.usb_otg.color = (1, 0, 0, 0.3)

        if self.items['usb_fw'].okay != None:
            if type(self.items['usb_fw'].value) == str:
                self.usb3_fw.text = self.items['usb_fw'].value
            else:
                self.usb3_fw.text = 'Error'
            if self.items['usb_fw'].okay == 1:
                self.usb3_fw.color = (0, 1, 0, 0.3)
            else:
                self.usb3_fw.color = (1, 0, 0, 0.3)

        if self.items['usb_speed'].ret != None:
            tmp = [str(x) for x in self.items['usb_speed'].value]
            self.usb3_0.text = tmp[0]
            self.usb3_1.text = tmp[1]
            self.usb3_2.text = tmp[2]
            self.usb3_3.text = tmp[3]

        if self.items['usb_cmp'].ret != None:
            if self.items['usb_cmp'].okay == 1:
                self.usb3_0.color = (0, 1, 0, 0.3)
                self.usb3_1.color = (0, 1, 0, 0.3)
                self.usb3_2.color = (0, 1, 0, 0.3)
                self.usb3_3.color = (0, 1, 0, 0.3)
            else:
                if self.items['usb_cmp'].value[0] == '0':
                    self.usb3_0.color = (0, 1, 0, 0.3)
                else:
                    self.usb3_0.text += self.items['usb_cmp'].value[0]
                    self.usb3_0.color = (1, 0, 0, 0.3)

                if self.items['usb_cmp'].value[1] == '0':
                    self.usb3_1.color = (0, 1, 0, 0.3)
                else:
                    self.usb3_1.text += self.items['usb_cmp'].value[1]
                    self.usb3_1.color = (1, 0, 0, 0.3)

                if self.items['usb_cmp'].value[2] == '0':
                    self.usb3_2.color = (0, 1, 0, 0.3)
                else:
                    self.usb3_2.text += self.items['usb_cmp'].value[2]
                    self.usb3_2.color = (1, 0, 0, 0.3)

                if self.items['usb_cmp'].value[3] == '0':
                    self.usb3_3.color = (0, 1, 0, 0.3)
                else:
                    self.usb3_3.text += self.items['usb_cmp'].value[3]
                    self.usb3_3.color = (1, 0, 0, 0.3)

        if self.items['gpio'].req != None:
            self.pb_gpio.value = sum(v.ret is not None for k, v in self.items_gpio.items())

        if self.items['gpio'].ret != None:
            if self.items['gpio'].okay == 1:
                self.gpio.text = 'OK'
                self.gpio.color = (0, 1, 0, 0.3)
            elif self.items['gpio'].okay == 0:
                self.gpio.text = self.items['gpio'].value
                self.gpio.color = (1, 0, 0, 0.3)
                self.pb_gpio.value = 30

        if self.items['iperf'].ack != None:
            self.pb_iperf.value = int(self.agent.pick_time() - self.items['iperf'].ack)

        if self.items['iperf'].okay != None:
            try:
                bandwidth = float(self.items['iperf'].value[0])
                loss = float(self.items['iperf'].value[1])
            except Exception as e:
                bandwidth = loss = None

            self.iperf.text = f'BW : {bandwidth}, Loss : {loss}'
            self.items['iperf'].ack = None
            self.pb_iperf.value = 11
            if self.items['iperf'].okay == 1:
                self.iperf.color = (0, 1, 0, 0.3)
            else:
                self.iperf.color = (1, 0, 0, 0.3)

        if self.items['led_sys'].okay != None:
            if self.items['led_sys'].okay == 1:
                self.led_sys.color = (0, 1, 0, 0.3)
            else:
                self.led_sys.color = (1, 0, 0, 0.3)

        if self.items['led_eth'].okay != None:
            if self.items['led_eth'].okay == 1:
                self.led_eth.color = (0, 1, 0, 0.3)
            else:
                self.led_eth.color = (1, 0, 0, 0.3)

        if self.items['edid'].okay != None:
            if self.items['edid'].okay == 1:
                self.edid.color = (0, 1, 0, 0.3)
            else:
                self.edid.color = (1, 0, 0, 0.3)

        if self.items['lirc'].okay != None:
            if self.items['lirc'].okay == 1:
                self.ir.color = (0, 1, 0, 0.3)
            else:
                self.ir.color = (1, 0, 0, 0.3)

        #if all(v.okay == 1 for k, v in self.items.items()):
        if not any(v.okay == None for k, v in self.items.items()):
            err = []
            for k, v in self.items.items():
                if k == 'uuid':
                    if v.okay == 0:
                        err.append(k)
                elif k == 'write_uuid':
                    if v.okay == 0:
                        err.append(k)
                else:
                    if v.okay == 0:
                        err.append(k)

            if 'uuid' in err and 'write_uuid' in err:
                print('error')
            elif 'uuid' in err:
                err.remove('uuid')
            elif 'write_uuid' in err:
                err.remove('write_uuid')

            if len(err) > 0:
                self.finish.color = (1, 0, 0, 0.3)
            else:
                self.finish.color = (0, 1, 0, 0.3)
            
        '''
        if all(v.okay == 1 for k, v in self.items.items()):
            self.finish.color = (0, 1, 0, 0.3)
        elif not any(v.okay == None for k, v in self.items.items()):
            self.finish.color = (1, 0, 0, 0.3)
        '''

class AgentUI(BoxLayout):
    ch0 = ObjectProperty(None)
    ch1 = ObjectProperty(None)

    async def init(self):
        loop = asyncio.get_event_loop()

        self.agent0 = Agent(loop, 0, C4)
        await self.agent0.init_tasks()
        self.ch0.name.text = 'Channel0'
        self.ch0.init(self.agent0)

        self.agent1 = Agent(loop, 1, C4)
        await self.agent1.init_tasks()
        self.ch1.name.text = 'Channel1'
        self.ch1.init(self.agent1)


        asyncef(self.update(self.ch0))
        asyncef(self.update(self.ch1))

    async def update(self, channel):
        while True:
            channel.update()
            await asyncio.sleep(0.5)

class AgentApp(App):
    def build(self):
        aui = AgentUI()
        asyncef(aui.init())

        return aui

    def app_func(self):
        async def run_wrapper():
            await self.async_run(async_lib='asyncio')
        return asyncio.gather(run_wrapper())

class Agent():
    def __init__(self, loop, channel=0, board=None):
        self.channel = channel
        self.board = board
        self.uart = Uart(channel, self.board.model)
        self.api = API_MANAGER(board='c4')
        self.adc = ADC(loop, 2 + channel)
        self.gpio = board.pins.gpio
        self.pwrs = board.pins.pwrs
        self.leds_sys = board.pins.leds_sys
        self.leds_eth = board.pins.leds_eth
        self.edid = board.pins.edid
        self.time = time.time()
        self.ipaddr_agent = None
        self.flag_ui_init = 0

        self.power_on = None

        self.labels_item = ['ipaddr', 'eth_speed', 'usb_hub', 'usb_fw', 'usb_speed',
                'otg_speed', 'usb_mount', 'usb_cmp', 'gpio', 'iperf', 'uuid',
                'write_uuid', 'led_sys', 'led_eth', 'edid', 'lirc', 'iperf_server']
        self.items = {k:Component() for k in self.labels_item}

        self.labels_gpio = [x.label for x in self.gpio]
        self.items_gpio = {k:Component() for k in self.labels_gpio}

        self.task_uart = Task(self.uart.available_uart)
        self.task_parse_msg = Task(self.parse_msg)
        self.task_sequence_main = Task(self.sequence_main)

        self.task_usb = Task(self.check_usb)
        self.task_gpio = Task(self.check_gpio)
        self.task_iperf = Task(self.check_iperf)
        self.task_led_sys = Task(self.check_led_sys)
        self.task_led_eth = Task(self.check_led_eth)

        self.mode = 'manual'
        self.seq_main = 0
        self.seq_gpio = 0

    def pick_time(self):
        return round(time.time() - self.time, 2)

    async def get_ipaddr(self):
        cmd = 'hostname -I'
        proc = await asyncio.create_subprocess_shell(cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await proc.communicate()
        if stderr != b'':
            LOG.error(stderr)
        return stdout.decode('utf-8').rstrip()

    async def init_tasks(self):
        asyncef(self.task_uart.run())
        asyncef(self.task_parse_msg.run())
        asyncef(self.task_sequence_main.run())
        asyncef(self.monitor_pwr())

    def init_variables(self):
        for k, v in self.items.items():
            v.req = v.ack = v.ret = v.seq = v.value = v.okay = None
        for k, v in self.items_gpio.items():
            v.req = v.ack = v.ret = v.seq = v.value = v.okay = None

    async def init_sequence(self):
        self.seq_main = 0
        self.seq_gpio = 0
        self.time = time.time()
        self.init_variables()
        self.flag_ui_init = 1

    async def write_uuid(self):
        self.items['write_uuid'].ret = None
        mac_string = await self.api.request_mac_addr()
        if mac_string == None:
            print('[[[[[[[[[[[[[[[[[ mac string none ]]]]]]]]]]]]]]]]]')
            self.items['write_uuid'].okay = 0
            self.items['uuid'].okay = 0
            return None

        asyncef(self.uart.send('cmd,eth,write_uuid,' + mac_string))
        self.items['write_uuid'].req = self.pick_time()
        await self.wait_ret(self.items['write_uuid'])
        mac = self.items['write_uuid'].value[-12:]
        if mac.startswith('001e06'):
            self.items['write_uuid'].okay = 1
            self.items['uuid'].okay = 0
        else:
            self.items['write_uuid'].okay = 0
            self.items['uuid'].okay = 0
        LOG.debug(f"okay : {self.items['write_uuid'].okay}")

    async def check_uuid(self):
        self.items['uuid'].ret = None
        asyncef(self.uart.send('cmd,eth,uuid'))
        self.items['uuid'].req = self.pick_time()
        ret = await self.wait_ret(self.items['uuid'])
        if ret == -1:
            self.items['uuid'].okay = 0
            self.items['write_uuid'].okay = 0
        elif self.items['uuid'].value[-12:].startswith('001e06'):
            self.items['uuid'].okay = 1
            self.items['write_uuid'].okay = 0
        else:
            asyncef(self.write_uuid())
        LOG.debug(f"okay : {self.items['uuid'].okay}")

    async def check_edid(self):
        try:
            self.items['edid'].ret = None
            asyncef(self.uart.send('cmd,edid,0'))
            self.items['edid'].req = self.pick_time()
            await self.wait_ret(self.items['edid'])
            ret = await self.adc.check_edid(self.edid, seq=0)
            if len(ret) != 0:
                self.items['edid'].okay = 0
                return
            self.items['edid'].ret = None
            asyncef(self.uart.send('cmd,edid,1'))
            self.items['edid'].req = self.pick_time()
            await self.wait_ret(self.items['edid'])
            ret = await self.adc.check_edid(self.edid, seq=1)
            if len(ret) == 0:
                self.items['edid'].okay = 1
            else:
                self.items['edid'].okay = 0
                self.items['edid'].value = ret

        except asyncio.CancelledError:
            LOG.debug("canceld edid")
            raise

    async def check_otg_speed(self):
        self.items['otg_speed'].ret = None
        asyncef(self.uart.send('cmd,usb,otg_speed'))
        self.items['otg_speed'].req = self.pick_time()
        await self.wait_ret(self.items['otg_speed'])
        if self.items['otg_speed'].value == '480':
            self.items['otg_speed'].okay = 1
        else:
            self.items['otg_speed'].okay = 0
        LOG.debug(f"okay : {self.items['otg_speed'].okay}")

    async def check_usb_hub(self):
        self.items['usb_hub'].ret = None
        asyncef(self.uart.send('cmd,usb,hub'))
        self.items['usb_hub'].req = self.pick_time()
        await self.wait_ret(self.items['usb_hub'])
        if self.items['usb_hub'].value == '2':
            self.items['usb_hub'].okay = 1
        else:
            self.items['usb_hub'].okay = 0
        LOG.debug(f"okay : {self.items['usb_hub'].okay}")

    async def check_usb_fw(self):
        self.items['usb_fw'].ret = None
        asyncef(self.uart.send('cmd,usb,fw'))
        self.items['usb_fw'].req = self.pick_time()
        await self.wait_ret(self.items['usb_fw'])
        if self.items['usb_fw'].value == '90.33':
            self.items['usb_fw'].okay = 1
        else:
            self.items['usb_fw'].okay = 0
        LOG.debug(f"okay : {self.items['usb_fw'].okay}")

    async def check_usb_speed(self):
        self.items['usb_speed'].ret = None
        asyncef(self.uart.send('cmd,usb,speed'))
        self.items['usb_speed'].req = self.pick_time()
        await self.wait_ret(self.items['usb_speed'])
        if all([x == '5000' for x in self.items['usb_speed'].value]):
            self.items['usb_speed'].okay = 1
        else:
            self.items['usb_speed'].okay = 0
        LOG.debug(f"okay : {self.items['usb_speed'].okay}")

    async def check_usb_mount(self):
        self.items['usb_mount'].ret = None
        asyncef(self.uart.send('cmd,usb,rw,mount'))
        self.items['usb_mount'].req = self.pick_time()
        await self.wait_ret(self.items['usb_mount'])
        if all([x == '0' for x in self.items['usb_mount'].value]):
            self.items['usb_mount'].okay = 1
            LOG.debug(f"okay : {self.items['usb_mount'].okay}")
        else:
            self.items['usb_mount'].okay = 0
            LOG.debug(f"okay : {self.items['usb_mount'].okay}")

    async def check_usb_cmp(self):
        self.items['usb_cmp'].ret = None
        asyncef(self.uart.send('cmd,usb,rw,cmp'))
        self.items['usb_cmp'].req = self.pick_time()
        await self.wait_ret(self.items['usb_cmp'], 15)
        if all([x == '0' for x in self.items['usb_cmp'].value]):
            self.items['usb_cmp'].okay = 1
            LOG.debug(f"okay : {self.items['usb_cmp'].okay}")
        else:
            self.items['usb_cmp'].okay = 0
            LOG.debug(f"okay : {self.items['usb_cmp'].okay}")


    async def check_lirc(self):
        self.items['lirc'].ret = None
        asyncef(self.uart.send('cmd,lirc'))
        self.items['lirc'].req = self.pick_time()
        await self.wait_ret(self.items['lirc'], 30)
        if self.items['lirc'].value == '0':
            self.items['lirc'].okay = 1
            LOG.debug(f"okay : {self.items['lirc'].okay}")
        else:
            self.items['lirc'].okay = 0
            LOG.debug(f"okay : {self.items['lirc'].okay}")

    async def check_ipaddr(self):
        self.items['ipaddr'].ret = None
        asyncef(self.uart.send('cmd,eth,ipaddr'))
        self.items['ipaddr'].req = self.pick_time()
        print('==============wait =============')
        ret = await self.wait_ret(self.items['ipaddr'])
        print('==============wait =============', ret)
        if ret == -1:
            self.items['ipaddr'].okay = 0
        elif self.items['ipaddr'].value.startswith('192.168.'):
            self.items['ipaddr'].okay = 1
            LOG.debug(f"okay : {self.items['ipaddr'].okay}")
        else:
            self.items['ipaddr'].okay = 0
            LOG.debug(f"okay : {self.items['ipaddr'].okay}")

    async def check_eth_speed(self):
        self.items['eth_speed'].ret = None
        asyncef(self.uart.send('cmd,eth,speed'))
        self.items['eth_speed'].req = self.pick_time()
        await self.wait_ret(self.items['eth_speed'])
        if self.items['eth_speed'].value == '1000':
            self.items['eth_speed'].okay = 1
            LOG.debug(f"okay : {self.items['eth_speed'].okay}")
        else:
            self.items['ipaddr'].okay = 0
            LOG.debug(f"okay : {self.items['eth_speed'].okay}")

    async def check_usb(self):
        await self.check_usb_hub()
        await self.check_usb_fw()
        await self.check_usb_speed()
        await self.check_usb_mount()
        await self.check_usb_cmp()
        '''
        while True:
            if self.seq_usb == 1:
                self.seq_usb += 1
                asyncef(self.uart.send('cmd,usb,hub'))
                self.items['usb_hub'].req = self.pick_time()
            elif self.seq_usb == 2:
                if self.pick_time() - self.items['usb_hub'].req > 5:
                    LOG.debug('ack timeout')
            elif self.seq_usb == 3:
                if self.pick_time() - self.items['usb_hub'].ack > 5:
                    LOG.debug('result timeout')
            elif self.seq_usb == 4:
                self.seq_usb += 1
                asyncef(self.uart.send('cmd,usb,speed'))
                self.items['usb_speed'].req = self.pick_time()
            elif self.seq_usb == 5:
                if self.pick_time() - self.items['usb_speed'].req > 5:
                    LOG.debug('ack timeout')
            elif self.seq_usb == 6:
                if self.pick_time() - self.items['usb_speed'].ack > 5:
                    LOG.debug('result timeout')
            await asyncio.sleep(1)
        '''

    async def wait_ack(self, item):
        count = 0
        while True:
            if item.ack != None:
                return
            if count > 5:
                return
            count += 1
            await asyncio.sleep(0.2)

    async def wait_ret(self, item, time=5):
        count = 0
        while True:
            if item.ret != None:
                return 0
            if count > time*2:
                return -1
            count += 1
            await asyncio.sleep(0.5)

    async def check_gpio(self):
        count = 0
        gpios = deepcopy(self.gpio)
        self.items['gpio'].req = self.pick_time()
        self.items['gpio'].value = ""
        while len(gpios) > count :
            if self.seq_gpio == count + 1:
                label = gpios[count].label

                self.items_gpio[label].req = self.pick_time()
                self.items_gpio[label].ack = None
                self.items_gpio[label].ret = None

                try:
                    asyncef(self.uart.send(f'cmd,gpio,{label}'))
                    await self.wait_ack(self.items_gpio[label])
                    ret = await self.adc.read_times(gpios, label)
                except asyncio.CancelledError:
                    LOG.debug("canceld gpio")
                    for k in self.adc.lock_adc:
                        self.adc.lock_adc[k] = 0
                    raise

                if type(ret) == list:
                    self.items_gpio[label].okay = 0
                    self.items['gpio'].value += f'{label} '
                    LOG.error(f'{ret}')
                    for i in ret:
                        for idx, j in enumerate(gpios):
                            if i == j.label:
                                del(gpios[idx])
                else:
                    self.items_gpio[label].okay = 1
                count += 1
            await asyncio.sleep(0.2)

        if all(v.okay for k, v in self.items_gpio.items()):
            self.items['gpio'].okay = 1
        else:
            self.items['gpio'].okay = 0
        self.items['gpio'].ret = self.pick_time()
        LOG.info(self.items['gpio'].ret - self.items['gpio'].req)

    async def check_led_sys(self):
        try:
            self.items['led_sys'].ret = None
            asyncef(self.uart.send('cmd,led,sys,1'))
            self.items['led_sys'].req = self.pick_time()
            await self.wait_ret(self.items['led_sys'])
            ret = await self.adc.check_sys_led(self.leds_sys, seq=0)
            if len(ret) != 0:
                self.items['led_sys'].okay = 0
                return
            self.items['led_sys'].ret = None
            asyncef(self.uart.send('cmd,led,sys,0'))
            self.items['led_sys'].req = self.pick_time()
            await self.wait_ret(self.items['led_sys'])
            ret = await self.adc.check_sys_led(self.leds_sys, seq=1)
            if len(ret) == 0:
                self.items['led_sys'].okay = 1
            else:
                self.items['led_sys'].okay = 0
                self.items['led_sys'].value = ret

        except asyncio.CancelledError:
            LOG.debug("canceld led_sys")
            raise

    async def check_led_eth(self):
        try:
            self.items['led_eth'].ret = None
            asyncef(self.uart.send('cmd,led,eth,1000'))
            self.items['led_eth'].req = self.pick_time()
            await self.wait_ret(self.items['led_eth'])
            ret = await self.adc.check_eth_led(self.leds_eth, speed=1000)
            if len(ret) != 0:
                self.items['led_eth'].okay = 0
                return
            self.items['led_eth'].ret = None
            asyncef(self.uart.send('cmd,led,eth,100'))
            self.items['led_eth'].req = self.pick_time()
            await self.wait_ret(self.items['led_eth'])
            ret = await self.adc.check_eth_led(self.leds_eth, speed=100)
            if len(ret) == 0:
                self.items['led_eth'].okay = 1
            else:
                self.items['led_eth'].okay = 0
                self.items['led_eth'].value = ret

        except asyncio.CancelledError:
            LOG.debug("canceld led_eth")
            raise

    async def prepare_server(self):
        self.items['iperf_server'].req = self.pick_time()
        place = UART_IPERF_EXTERNAL_HOST_MAP[self.uart.uart['place']]
        asyncef(self.uart.send(f'cmd,server,{place}'))
        await self.wait_ret(self.items['iperf_server'])

    async def check_iperf(self):
        try:
            await self.prepare_server()
            if self.items['iperf_server'].value == '0':
                self.items['iperf_server'].okay = 1
            else:
                self.items['iperf_server'].okay = 1
            self.items['iperf'].req = self.pick_time()
            asyncef(self.uart.send(f'cmd,eth,iperf'))
            await self.wait_ret(self.items['iperf'], 15)
            if self.items['iperf'].value == None:
                self.items['iperf'].okay = 0
            else:
                bandwidth = float(self.items['iperf'].value[0])
                loss = float(self.items['iperf'].value[1])
                if bandwidth > 800 and loss < 10:
                    self.items['iperf'].okay = 1
                else:
                    self.items['iperf'].okay = 0
            LOG.debug(f"okay : {self.items['iperf'].okay}")
        except asyncio.CancelledError:
            LOG.debug("canceld iperf")
            raise

    async def sequence_main(self):
        while True:
            if self.seq_main == 1:
                self.seq_gpio = 1
                self.seq_main = 2

                asyncef(self.check_lirc())
                asyncef(self.check_ipaddr())
                asyncef(self.check_eth_speed())
                asyncef(self.check_uuid())
                asyncef(self.check_edid())
                asyncef(self.check_otg_speed())
                asyncef(self.task_gpio.run())
                asyncef(self.task_usb.run())
                asyncef(self.task_led_sys.run())
                asyncef(self.task_iperf.run())

            elif self.seq_main == 2:
                if self.items['iperf'].okay != None:
                    asyncef(self.task_led_eth.run())
                    self.seq_main = 3
            await asyncio.sleep(1)
    async def monitor_pwr(self):
        pre_power = None
        pre_uart = -1
        async for self.power_on in self.adc.check_pwr(self.pwrs):
            if self.uart.uart['alive'] != pre_uart:
                if self.uart.uart['node'] == None:
                    'update ui'
                    pass
                else:
                    'update ui'
                    pass
                pre_uart = self.uart.uart['alive']

            if pre_power != self.power_on:
                pre_power = self.power_on
                if self.power_on:
                    await self.init_sequence()
            await asyncio.sleep(0.3)
        
    async def parse_eth(self, cmd, data, size):
        if cmd == 'ack':
            if data[0] == 'ipaddr':
                self.items['ipaddr'].ack = self.pick_time()
            elif data[0] == 'speed':
                self.items['eth_speed'].ack = self.pick_time()
            elif data[0] == 'iperf':
                self.items['iperf'].ack = self.pick_time()
            elif data[0] == 'uuid':
                self.items['uuid'].ack = self.pick_time()
            elif data[0] == 'write_uuid':
                self.items['write_uuid'].ack = self.pick_time()

        elif cmd == 'ret':
            if data[0] == 'ipaddr':
                self.items['ipaddr'].ret = self.pick_time()
                self.items['ipaddr'].value = data[1]
                LOG.info(self.items['ipaddr'].value)
            elif data[0] == 'speed':
                self.items['eth_speed'].ret = self.pick_time()
                self.items['eth_speed'].value = data[1]
                LOG.info(self.items['eth_speed'].value)
            elif data[0] == 'iperf':
                self.items['iperf'].ret = self.pick_time()
                self.items['iperf'].value = data[1:3]
                LOG.info(self.items['iperf'].value)
            elif data[0] == 'uuid':
                self.items['uuid'].ret = self.pick_time()
                self.items['uuid'].value = data[1]
                LOG.info(self.items['uuid'].value)
            elif data[0] == 'write_uuid':
                self.items['write_uuid'].ret = self.pick_time()
                self.items['write_uuid'].value = data[1]
                LOG.info(self.items['write_uuid'].value)

    async def parse_led(self, cmd, data, size):
        if cmd == 'ack':
            if data[0] == 'sys':
                self.items['led_sys'].ack = self.pick_time()
            elif data[0] == 'sys':
                self.items['led_eth'].ack = self.pick_time()
        elif cmd == 'ret':
            if data[0] == 'sys':
                self.items['led_sys'].ret = self.pick_time()
                self.items['led_sys'].seq = data[1]
                self.items['led_sys'].value = data[2]
                LOG.info(self.items['led_sys'].value)
            elif data[0] == 'eth':
                self.items['led_eth'].ret = self.pick_time()
                self.items['led_eth'].seq = data[1]
                self.items['led_eth'].value = data[2]
                LOG.info(self.items['led_eth'].value)

    async def parse_edid(self, cmd, data, size):
        if cmd == 'ack':
            if data[0] == '0':
                self.items['edid'].ack = self.pick_time()
            elif data[0] == '1':
                self.items['edid'].ack = self.pick_time()

        elif cmd == 'ret':
                self.items['edid'].ret = self.pick_time()
                self.items['edid'].seq = data[0]
                self.items['edid'].value = data[1]
                LOG.info(self.items['edid'].value)

    async def parse_lirc(self, cmd, data):
        if cmd == 'ack':
            self.items['lirc'].ack = self.pick_time()
        elif cmd == 'ret':
            self.items['lirc'].ret = self.pick_time()
            self.items['lirc'].value = data[0]
            LOG.info(self.items['lirc'].value)

    async def parse_server(self, cmd, data):
        if cmd == 'ack':
            self.items['iperf_server'].ack = self.pick_time()
        elif cmd == 'ret':
            self.items['iperf_server'].ret = self.pick_time()
            self.items['iperf_server'].value = data[2]
            LOG.info(self.items['iperf_server'].value)

    async def parse_usb(self, cmd, data, size):
        if cmd == 'ack':
            if data[0] == 'hub':
                self.items['usb_hub'].ack = self.pick_time()
            elif data[0] == 'otg_speed':
                self.items['otg_speed'].ack = self.pick_time()
            elif data[0] == 'speed':
                self.items['usb_speed'].ack = self.pick_time()
            elif data[0] == 'fw':
                self.items['usb_fw'].ack = self.pick_time()
            elif data[0] == 'rw':
                if data[1] == 'mount':
                    self.items['usb_mount'].ack = self.pick_time()
                elif data[1] == 'cmp':
                    self.items['usb_cmp'].ack = self.pick_time()

        elif cmd == 'ret':
            if data[0] == 'hub':
                self.items['usb_hub'].ret = self.pick_time()
                self.items['usb_hub'].value = data[1]
                LOG.info(self.items['usb_hub'].value)
            elif data[0] == 'fw':
                self.items['usb_fw'].ret = self.pick_time()
                self.items['usb_fw'].value = data[1]
                LOG.info(self.items['usb_fw'].value)
            elif data[0] == 'otg_speed':
                self.items['otg_speed'].ret = self.pick_time()
                self.items['otg_speed'].value = data[1]
                LOG.info(self.items['otg_speed'].value)
            elif data[0] == 'speed':
                self.items['usb_speed'].ret = self.pick_time()
                self.items['usb_speed'].value = data[1:]
                LOG.info(self.items['usb_speed'].value)
            elif data[0] == 'rw':
                if data[1] == 'mount':
                    self.items['usb_mount'].ret = self.pick_time()
                    self.items['usb_mount'].value = data[2:]
                    LOG.info(self.items['usb_mount'].value)
                elif data[1] == 'cmp':
                    self.items['usb_cmp'].ret = self.pick_time()
                    self.items['usb_cmp'].value = data[2:]
                    LOG.info(self.items['usb_cmp'].value)

    async def parse_msg(self):
        async for cmd, data in self.uart.recv():
            size = len(data)
            if cmd == 'boot' and data[0] == 'done':
                if self.seq_main != 0:
                    await self.init_sequence()
                self.seq_main = 1
            elif cmd == 'ack':
                if data[0] == 'eth':
                    asyncef(self.parse_eth(cmd, data[1:], size-1))
                elif data[0] == 'usb':
                    asyncef(self.parse_usb(cmd, data[1:], size-1))
                elif data[0] == 'gpio':
                    self.items_gpio[data[1]].ack = self.pick_time()
                elif data[0] == 'led':
                    asyncef(self.parse_led(cmd, data[1:], size-1))
                elif data[0] == 'edid':
                    asyncef(self.parse_edid(cmd, data[1:], size-1))
                elif data[0] == 'lirc':
                    asyncef(self.parse_lirc(cmd, data[0]))
                elif data[0] == 'server':
                    asyncef(self.parse_server(cmd, data[0]))
            elif cmd == 'ret':
                if data[0] == 'eth':
                    asyncef(self.parse_eth(cmd, data[1:], size-1))
                elif data[0] == 'usb':
                    asyncef(self.parse_usb(cmd, data[1:], size-1))
                elif data[0] == 'gpio':
                    self.items_gpio[data[1]].ret = self.pick_time()
                    self.seq_gpio += 1
                elif data[0] == 'led':
                    asyncef(self.parse_led(cmd, data[1:], size-1))
                elif data[0] == 'edid':
                    asyncef(self.parse_edid(cmd, data[1:], size-1))
                elif data[0] == 'lirc':
                    asyncef(self.parse_lirc(cmd, data[1:]))
                elif data[0] == 'server':
                    asyncef(self.parse_server(cmd, data))

def main(argv):
    loop = asyncio.get_event_loop()

    if len(argv) > 0 and argv[0] == '-c':
        asyncef(agent.uart.send(argv[1]))
    else:
        asyncef(AgentApp().app_func())

    try:
        loop.run_forever()
    except KeyboardInterrupt:
        pass
    finally:
        pass

if __name__ == "__main__":
    main(sys.argv[1:])
