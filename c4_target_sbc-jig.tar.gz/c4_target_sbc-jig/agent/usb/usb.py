from .constants import *

class USB():
    def __init__(self):
        pass

    async def check_usb_speed(self):
        self.items['usb_speed'].ret = None
        asyncef(self.uart.send('cmd,usb,speed'))
        self.items['usb_speed'].req = self.pick_time()
        await self.wait_ret(self.items['usb_speed'])
        if all([x == '5000' for x in self.items['usb_speed'].value]):
            self.items['usb_speed'].okay = 1
            LOG.debug(f"okay : {self.items['usb_speed'].okay}")
        else:
            self.items['usb_speed'].okay = 0
            LOG.debug(f"okay : {self.items['usb_speed'].okay}")

    async def check_usb_hub(self):
        self.items['usb_hub'].ret = None
        asyncef(self.uart.send('cmd,usb,hub'))
        self.items['usb_hub'].req = self.pick_time()
        await self.wait_ret(self.items['usb_hub'])
        if self.items['usb_hub'].value == '2':
            self.items['usb_hub'].okay = 1
            LOG.debug(f"okay : {self.items['usb_hub'].okay}")
        else:
            self.items['usb_hub'].okay = 0
            LOG.debug(f"okay : {self.items['usb_hub'].okay}")

    async def check_usb_mount(self):
        self.items['usb_mount'].ret = None
        asyncef(self.uart.send('cmd,usb,rw,mount'))
        self.items['usb_mount'].req = self.pick_time()
        await self.wait_ret(self.items['usb_mount'])
        print(self.items['usb_mount'].value)
        if all([x == '0' for x in self.items['usb_mount'].value]):
            self.items['usb_mount'].okay = 1
            LOG.debug(f"okay : {self.items['usb_mount'].okay}")
        else:
            self.items['usb_mount'].okay = 0
            LOG.debug(f"okay : {self.items['usb_mount'].okay}")

