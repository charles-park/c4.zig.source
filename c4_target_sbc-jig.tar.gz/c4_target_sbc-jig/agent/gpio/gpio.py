from gpio.pin import *

gpx17 = Pin(0x9, 0xf, "GPIOX_17")
gpx18 = Pin(0x9, 0xb, "GPIOX_18")
gpx5 = Pin(0x9, 0xe, "GPIOX_5")
gpx12 = Pin(0x9, 0xa, "GPIOX_12")
gpx13 = Pin(0x9, 0xd, "GPIOX_13")
gpx3 = Pin(0x9, 0x9, "GPIOX_3")
gpx16 = Pin(0x9, 0xc, "GPIOX_16")
gpx4 = Pin(0x9, 0x8, "GPIOX_4")

gpx7 = Pin(0xa, 0xf, "GPIOX_7")
gpx0 = Pin(0xa, 0xb, "GPIOX_0")
gpx1 = Pin(0xa, 0xe, "GPIOX_1")
gpx8 = Pin(0xa, 0xa, "GPIOX_8")
gpx9 = Pin(0xa, 0xd, "GPIOX_9")
gpx2 = Pin(0xa, 0x9, "GPIOX_2")
gpx11 = Pin(0xa, 0xc, "GPIOX_11")
gpx10 = Pin(0xa, 0x8, "GPIOX_10")

gph6 = Pin(0xb, 0xf, "GPIOH_6")
gpa14 = Pin(0xb, 0xb, "GPIOAO_14")
gpa15 = Pin(0xb, 0xe, "GPIOAO_15")
gpx14 = Pin(0xb, 0xa, "GPIOX_14")
gpx15 = Pin(0xb, 0xd, "GPIOX_15")
gph7 = Pin(0xb, 0x9, "GPIOH_7")
gpx6 = Pin(0xb, 0xc, "GPIOX_6")
gpx19 = Pin(0xb, 0x8, "GPIOX_19")

gph5 = Pin(0x18, 0xf, "GPIOH_5")
gpa10 = Pin(0x18, 0xb, "GPIOAO_10")
gpa9 = Pin(0x18, 0xe, "GPIOAO_9")
gpa7 = Pin(0x18, 0xa, "GPIOAO_7")
gpa8 = Pin(0x18, 0xd, "GPIOAO_8")
gpa4 = Pin(0x18, 0x9, "GPIOAO_4")

vcc3_1 = Pin(0x8, 0xf, "V3_J2_1")
vcc5_1 = Pin(0x8, 0xb, "V5_J2_2")
vcc5_2 = Pin(0x8, 0xe, "V5_J2_4")
vcc3_2 = Pin(0x8, 0xa, "V3_J2_17")
vddio = Pin(0x8, 0xd, "V18_J2_38")
vcc5_3 = Pin(0x8, 0x9, "V5_J7_3")

led_led = Pin(0x8, 0xc, "LED_RED")
led_blue = Pin(0x8, 0x8, "LED_BLUE")
led_green = Pin(0x19, 0xf, "LED_GREEN")
led_yellow = Pin(0x19, 0xb, "LED_YELLOW")

edid_scl = Pin(0x19, 0xa, "EDID_SCL")
edid_sda = Pin(0x19, 0xe, "EDID_SDA")


PIN_GPIOS_C4 = [gpx17, gpx18, gpx5, gpx12, gpx13, gpx3, gpx16, gpx4,
        gpx7, gpx0, gpx1, gpx8, gpx9, gpx2, gpx11, gpx10,
        gph6, gpa14, gpa15, gpx14, gpx15, gph7, gpx6, gpx19,
        gph5, gpa10, gpa9, gpa7, gpa8, gpa4]

PIN_PWR_C4 = [vcc3_1, vcc5_1, vcc5_2, vcc3_2, vddio, vcc5_3]
PIN_LEDS_SYS_C4 = [led_led, led_blue]
PIN_LEDS_ETH_C4 = [led_green, led_yellow]
PIN_EDID_C4 = [edid_scl, edid_sda]

class GPIO():
    def __init__(self, model):
        if model == 'C4':
            self.gpio = PIN_GPIOS_C4
            self.pwrs = PIN_PWR_C4
            self.leds_sys = PIN_LEDS_SYS_C4
            self.leds_eth = PIN_LEDS_ETH_C4
            self.edid = PIN_EDID_C4
