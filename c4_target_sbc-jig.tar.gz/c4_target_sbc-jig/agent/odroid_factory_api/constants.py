API_SERVER_HOST = 'https://factory.hardkernel.kro.kr:8880'
API_TEST_SERVER_HOST = 'https://factory-dev.hardkernel.kro.kr:8880'

API_USER_INFO = {
    'username': 'odroid',
    'password': 'hard4624',
}

API_POST_URL = {
    'login': '/restapi/login',
    'request': '/restapi/request',
    'update': '/restapi/update',
    'delete': '/restapi/delete',
    'criteria': '/restapi/criteria',
}

# 2019. 4. 9
API_N2_ALL_FIELDS_LIST = [
    'mac_num',
    'assigned',
    'assigned_date',
    'board',
    'ram',
    'uuid',
    'usb_firmware',
    'usb_3_0_bandwidth',
    'usb_3_1_bandwidth',
    'usb_3_2_bandwidth',
    'usb_3_3_bandwidth',
    'usb_3_0_file_io_pass',
    'usb_3_1_file_io_pass',
    'usb_3_2_file_io_pass',
    'usb_3_3_file_io_pass',
    'usb_2_bandwidth',
    'usb_2_communicate_pass',
    'ethernet_bandwidth',
    'ethernet_ping_pass',
    'hdmi_cec_pass',
    'hdmi_i2c_pass',
    'fan_pass',
    'gpio_pass',
    'gpio_fail',
    'adc_pass',
    'adc_fail',
    'led_ethernet_amber_pass',
    'led_ethernet_green_pass',
    'led_power_pass',
    'led_system_pass',
    'ir_pass',
    'audio_pass',
    'slide_switch_pass',
    'iperf_rx_udp_bandwidth',
    'iperf_rx_udp_loss_rate',
    'rsync_transfer_speed',
]
