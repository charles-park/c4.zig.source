# asyncio unittest example: https://gist.github.com/ly0/b3be4a5b7708a9a8c3da

import unittest
import asyncio
import inspect
import sys

import api
import constants


def async_test(function):
    def wrapper(*args, **kwargs):
        if inspect.iscoroutinefunction(function):
            future = function(*args, **kwargs)
        else:
            coroutine = asyncio.coroutine(function)
            future = coroutine(*args, **kwargs)
        asyncio.get_event_loop().run_until_complete(future)
    return wrapper


class TestApi(unittest.TestCase):

    def __init__(self, *args, **kwargs):
        super(TestApi, self).__init__(*args, **kwargs)
        self.api_manager = api.API_MANAGER(
            board='n2',
            server_host=constants.API_TEST_SERVER_HOST
        )
        self.api_manager.mac_addr = '001e06420001'

    @async_test
    async def test_request_mac_addr(self):
        results = await self.api_manager.request_mac_addr()
        self.assertEqual(len(results), 36)

    @async_test
    async def test_delete_assigned_sign(self):
        await self.api_manager.request_mac_addr()
        results = await self.api_manager.delete_assigned_sign()
        self.api_manager.mac_addr = '001e06420001'
        self.assertIsNotNone(results)

    @async_test
    async def test_get_criteria(self):
        results = await self.api_manager.get_criteria_for_board()
        self.assertIsNotNone(results)

    @async_test
    async def test_update_ram_results(self):
        results = await self.api_manager.update_ram_results(
            ram='3.62'
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_uuid_results(self):
        results = await self.api_manager.update_uuid_results(
            uuid='12345678-1234-1234-1234-123456789012'
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_usb_results_partly_1(self):
        results = await self.api_manager.update_usb_results(
            usb_firmware='ffffff'
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_usb_results_partly_2(self):
        results = await self.api_manager.update_usb_results(
            usb_3_bandwidth=[ 0, 100, 2500, 5000 ],
            usb_3_file_io_pass=[ False, True, True, True ]
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_usb_results_partly_3(self):
        results = await self.api_manager.update_usb_results(
            usb_2_bandwidth=480,
            usb_2_communicate_pass=True
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_ethernet_results(self):
        results = await self.api_manager.update_ethernet_results(
            ethernet_bandwidth=1000,
            is_ping_pass=True
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_hdmi_results_partly_1(self):
        results = await self.api_manager.update_hdmi_results(
            is_cec_pass=True
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_hdmi_results_partly_2(self):
        results = await self.api_manager.update_hdmi_results(
            is_i2c_pass=True
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_fan_results(self):
        results = await self.api_manager.update_fan_results(
            is_pass=True
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_gpio_results(self):
        """
        Assume it fails to check if it stores which GPIO numbers fails
        """
        results = await self.api_manager.update_gpio_results(
            is_pass=False,
            fail_nums=[ 0, 100, 1000, 10000 ]
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_adc_results(self):
        """
        Assume it fails to check if it stores which ADC numbers fails
        """
        results = await self.api_manager.update_adc_results(
            is_pass=False,
            fail_nums=[ 0, 100, 1000, 10000 ]
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_led_ethernet_results(self):
        results = await self.api_manager.update_led_ethernet_results(
            is_amber_pass=True,
            is_green_pass=True
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_led_power_system_results(self):
        results = await self.api_manager.update_led_power_system_results(
            is_power_pass=True,
            is_system_pass=True
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_ir_results(self):
        results = await self.api_manager.update_ir_results(
            is_ir_pass=True
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_audio_results(self):
        results = await self.api_manager.update_audio_results(
            is_audio_pass=True
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_switch_results(self):
        results = await self.api_manager.update_switch_results(
            is_switch_pass=True
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_iperf_udp_results(self):
        results = await self.api_manager.update_iperf_udp_results(
            bandwidth=999.99,
            loss_rate=99.99
        )
        self.assertEqual(results['isUpdated'], True)

    @async_test
    async def test_update_rsync_results(self):
        results = await self.api_manager.update_rsync_results(
            transfer_speed='90.01MB/s,100.02MB/s,110.03MB/s'
        )
        self.assertEqual(results['isUpdated'], True)

if __name__ == '__main__':
    unittest.main()
