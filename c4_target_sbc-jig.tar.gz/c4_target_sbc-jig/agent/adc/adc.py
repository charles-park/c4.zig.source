from smbus2 import SMBus
import asyncio
from .constants import *
import time
from asyncio import ensure_future as asyncef

class ADC():
    def __init__(self, loop, bus=None):
        self.loop = loop
        self.lock_adc = {0x8: 0, 0x9: 0, 0xa: 0, 0xb: 0, 0x18: 0, 0x19: 0}

        try:
            self.bus = SMBus(bus)
        except FileNotFoundError as e:
            print(f'file no found {e}')
        except IOError as e:
            print(f'io error {e}')

    async def lock(self, addr):
        while self.lock_adc[addr] != 0:
            await asyncio.sleep(0.01)
        self.lock_adc[addr] = 1

    async def unlock(self, addr):
        self.lock_adc[addr] = 0

    async def read_power(self, pwrs):
        res = [asyncef(self._read(i.addr, i.channel, i.label)) for i in pwrs]
        result = (await asyncio.gather(*res))
        off = []
        for i in result:
            if i[0].startswith("V5"):
                if i[1] < HIGH_V5:
                    off.append(i[0])
            elif i[0].startswith("V3"):
                if i[1] < HIGH_V3:
                    off.append(i[0])
            elif i[0].startswith("V18"):
                if i[1] < HIGH_V18:
                    off.append(i[0])
        return off

    async def check_eth_led(self, leds, speed):
        count = 0
        ret = []
        while count < 30:
            ret = await self._check_eth_led(leds, speed)
            if len(ret) == 0:
                break
            count += 1
            await asyncio.sleep(0.2)
        return ret

    async def _check_eth_led(self, leds, speed):
        res = [asyncef(self._read(i.addr, i.channel, i.label)) for i in leds]
        result = (await asyncio.gather(*res))
        fail = []
        for i in result:
            if i[0] == "LED_YELLOW" and speed  == 1000:
                if i[1] < 0.3:
                    fail.append(i[0])
                    LOG.debug(f"High failed {i[0]} : {i[1]}")
            elif i[0] == "LED_YELLOW" and speed  == 100:
                if i[1] > 0.1:
                    fail.append(i[0])
                    LOG.debug(f"High failed {i[0]} : {i[1]}")
            if i[0] == "LED_GREEN" and speed  == 1000:
                if i[1] > 0.1:
                    fail.append(i[0])
                    LOG.debug(f"High failed {i[0]} : {i[1]}")
            elif i[0] == "LED_GREEN" and speed == 100:
                if i[1] < 0.3:
                    fail.append(i[0])
                    LOG.debug(f"LOW failed {i[0]} : {i[1]}")
        return fail

    async def check_sys_led(self, leds, seq):
        count = 0
        ok = 0
        ret = []
        while count < 6*4:
            ret = await self._check_sys_led(leds, seq)
            if len(ret) == 0:
                ok += 1
            else:
                ok = 0
            if ok > 2:
                break
            count += 1
            await asyncio.sleep(0.3)
        return ret

    async def _check_sys_led(self, leds, seq):
        res = [asyncef(self._read(i.addr, i.channel, i.label)) for i in leds]
        result = (await asyncio.gather(*res))
        fail = []
        for i in result:
            if i[0] == "LED_RED":
                if i[1] < 0.3:
                    fail.append(i[0])
                    LOG.debug(f"High failed {i[0]} : {i[1]}")
            if i[0] == "LED_BLUE" and seq == 0:
                if i[1] < 0.3:
                    fail.append(i[0])
                    LOG.debug(f"High failed {i[0]} : {i[1]}")
            elif i[0] == "LED_BLUE" and seq == 1:
                if i[1] > 0.1:
                    fail.append(i[0])
                    LOG.debug(f"LOW failed {i[0]} : {i[1]}")
        return fail

    async def check_edid(self, pins, seq):
        count = 0
        ret = []
        while count < 5*2:
            ret = await self._check_edid(pins, seq)
            if len(ret) == 0:
                break
            count += 1
            await asyncio.sleep(0.5)
        return ret

    async def _check_edid(self, pins, seq):
        res = [asyncef(self._read(i.addr, i.channel, i.label)) for i in pins]
        result = (await asyncio.gather(*res))
        fail = []
        for i in result:
            if i[0] == "EDID_SCL" and seq == 0:
                if i[1] < 3:
                    fail.append(i[0])
                    LOG.debug(f"High failed {i[0]} : {i[1]}")
            elif i[0] == "EDID_SCL" and seq == 1:
                if i[1] > 1:
                    fail.append(i[0])
                    LOG.debug(f"LOW failed {i[0]} : {i[1]}")

            if i[0] == "EDID_SDA" and seq == 1:
                if i[1] < 3:
                    fail.append(i[0])
                    LOG.debug(f"High failed {i[0]} : {i[1]}")
            elif i[0] == "EDID_SDA" and seq == 0:
                if i[1] > 1:
                    fail.append(i[0])
                    LOG.debug(f"LOW failed {i[0]} : {i[1]}")
        return fail

    async def check_pwr(self, pwrs):
        while True:
            off = await self.read_power(pwrs)
            if len(off) != 0:
                LOG.debug(off)
                yield 0
            else:
                yield 1
            await asyncio.sleep(0.5)

    async def read_pin(self, pins, label):
        for i in pins:
            if i.label == label:
                ret = await self._read(i.addr, i.channel, i.label)
                print(ret)

    async def read(self, pins, label):
        try:
            res = [asyncef(self._read(i.addr, i.channel, i.label)) for i in pins]
            result = (await asyncio.gather(*res))
            fail = []
            for i in result:
                if i[0] == label:
                    if i[1] < HIGH:
                        fail.append(i[0])
                        LOG.debug(f"High failed {i[0]} : {i[1]}")
                else:
                    if i[1] > LOW:
                        fail.append(i[0])
                        LOG.debug(f"Low failed {i[0]} : {i[1]}")
        except Exception as e:
            print(e)
        return fail

    async def read_times(self, pins, label):
        count = 0
        while count < 10:
            ret = await self.read(pins, label)
            if len(ret) == 0:
                return 0
            count += 1
            await asyncio.sleep(0.5)
        return ret

    async def _read(self, addr, channel, label):
        await self.lock(addr)
        channel = (channel << 4) | 0x8
        await asyncio.sleep(0.01)
        try:
            self.bus.write_byte(addr, channel)
            await asyncio.sleep(0.01)
            reading = self.bus.read_i2c_block_data(addr, channel, 2)
            await self.unlock(addr)
        except OSError as e:
            await self.unlock(addr)
            return label, -1
        except Exception as e:
            await self.unlock(addr)
            return label, -1
        valor = (reading[0] << 4) + (reading[1] >> 4)
        return label, float(f'{valor*5/4096:0.2f}')
