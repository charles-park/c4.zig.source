from pin import Pin
import gpiodcxx as gpiod

config = gpiod.line_request()
config.consumer = "USB writer"
config.request_type = gpiod.line_request.DIRECTION_OUTPUT
#config.request_type = gpiod.line_request.DIRECTION_INPUT

class GPIO():
    def __init__(self):
        self.led = Pin(0, "GPIOAO_11", config)
        self.led.set_value(1)
        self.reset = None
    def error(self):
        self.reset = Pin(1, "GPIOH_8", config)

if __name__ == "__main__":
    gpio = GPIO()
    print(gpio.led.set_value(1))
