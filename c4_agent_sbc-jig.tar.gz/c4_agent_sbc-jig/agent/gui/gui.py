'''Example shows the recommended way of how to run Kivy with the Python built
in asyncio event loop as just another async coroutine.
'''
import asyncio

from kivy.uix.widget import Widget
from kivy.uix.boxlayout import BoxLayout
from kivy.app import App
from kivy.config import Config
from kivy.properties import ObjectProperty
import os

Config.set('graphics', 'fullscreen', 'fake')
Config.set('graphics', 'width', '1024')
Config.set('graphics', 'height', '600')

os.environ['DISPLAY'] = ":0.0"

class GUI(BoxLayout):

    onoff = ObjectProperty()

    def __init__(self, agent):
        self.agent = agent


class GUIApp(App):
    def __init__(self, agent):
        self.agent = agent

    def build(self):
        gui = GUI(self.agent)
        return gui

    def app_func(self):
        async def run_wrapper():
            await self.async_run(async_lib='asyncio')

        return asyncio.gather(run_wrapper())

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(GUIApp().app_func())
    loop.close()
