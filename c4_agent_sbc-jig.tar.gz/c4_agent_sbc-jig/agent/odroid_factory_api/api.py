import asyncio
import aiohttp

try:
    from . import constants
except ImportError:
    import constants


class API_MANAGER:

    def __init__(self, board, server_host=None):
        if server_host is None:
            server_host = constants.API_SERVER_HOST
        self.server_host = server_host
        self.mac_addr = None
        self.uuid_mac = None
        self.board = board.lower()

        # For debugging for now
        self.update_last_return = None
        self.api_auth_last_informed_expires_in = None
        self.api_auth_last_token = None

    async def _login_to_api_server(self):
        try:
            print(f'API: Try to login to the API server')

            async with aiohttp.ClientSession() as session:
                response = await session.post(
                    url=self.server_host + constants.API_POST_URL['login'],
                    headers={
                        'content-type': 'application/json'
                    },
                    ssl=False,
                    json=constants.API_USER_INFO
                )
                response = await response.json()
        except Exception as error:
            print(f'API Exception: {str(error)}')
            return None

        if 'error' not in response:
            print(f'API: Success: {response}')
            self.api_auth_last_informed_expires_in = response['expires_in']
            self.api_auth_last_token = response['token']
            return response
        else:
            print(f'API: Error: {response}')
            return response

    async def _update_record(self, data):
        # Necessaries
        if (type(data) is not dict) or self.mac_addr is None or self.board is None:
            print(f'api : mac {self.mac_addr}, board {self.board}')
            return

        # Filters invalid fields
        for entry in data:
            if entry not in constants.API_N2_ALL_FIELDS_LIST:
                return { 'error': 'Invalid column found: ' + entry }

        data['mac_addr'] = self.mac_addr
        data['board'] = self.board

        try:
            response = await self._login_to_api_server()
            if 'error' in response:
                return { 'error': 'API login error: ' + response['error'] }

            print(f'API: Try to send data: {data}')

            async with aiohttp.ClientSession() as session:
                response = await session.post(
                    url=self.server_host + constants.API_POST_URL['update'],
                    headers={
                        'content-type': 'application/json',
                        'Authorization': 'Token ' + response['token']
                    },
                    ssl=False,
                    json=data
                )
                response = await response.json()
        except Exception as error:
            print(f'API Exception: {str(error)}')
            return None

        if 'error' not in response:
            print(f'API: Success: {response}')
            self.last_update_return = response
            return response
        else:
            print(f'API: Error: {response}')
            return None

    async def update_ram_results(self, ram):
        '''
        Usage)
        update_ram_results(
            ram='3.62'
        )
        '''

        if not isinstance(ram, (float, str)):
            return { 'error': 'uuid must be float or str type' }

        return await self._update_record(data={
            'ram': ram
        })

    async def update_uuid_results(self, uuid):
        '''
        Usage)
        update_uuid_results(
            uuid='12345678-1234-1234-1234-123456789012'
        )
        '''

        if type(uuid) is not str and len(uuid) != 36:
            return { 'error': 'uuid must be str type and has length 36' }

        return await self._update_record(data={
            'uuid': uuid
        })

    async def update_usb_results(self, usb_firmware=None, usb_3_bandwidth=None, usb_3_file_io_pass=None, usb_2_bandwidth=None, usb_2_communicate_pass=None):
        '''
        Usage)
        update_usb_results(
            usb_firmware='fffffff',
            usb_3_bandwidth=[ 5000, 5000, 5000, 5000 ] # USB3_0, 3_1, 3_2, 3_3
            usb_3_file_io_pass=[ True, True, True, True ] # USB3_0, 3_1, 3_2, 3_3
            usb_2_bandwidth=480
            usb_2_communicate_pass=True
        )
        '''

        data = {}
        if usb_firmware is not None:
            if type(usb_firmware) is not str and len(usb_firmware) > 7:
                return { 'error': 'usb_firmware must be str type and has length less than 8' }
            else:
                data['usb_firmware'] = usb_firmware
        
        if usb_3_bandwidth is not None:
            if type(usb_3_bandwidth) is not list and len(usb_3_bandwidth) != 4:
                return { 'error': 'usb_3_bandwidth must be dict type and has 4 elements'}
            else:
                for item in usb_3_bandwidth:
                    if type(item) is not int:
                        return { 'error': 'an item in usb_3_bandwidth must be int type'}

                data['usb_3_0_bandwidth'] = usb_3_bandwidth[0]
                data['usb_3_1_bandwidth'] = usb_3_bandwidth[1]
                data['usb_3_2_bandwidth'] = usb_3_bandwidth[2]
                data['usb_3_3_bandwidth'] = usb_3_bandwidth[3]

        if usb_3_file_io_pass is not None:
            if type(usb_3_file_io_pass) is not list and len(usb_3_file_io_pass) != 4:
                return { 'error': 'usb_3_file_io_pass must be dict type and has 4 elements'}
            else:
                for item in usb_3_file_io_pass:
                    if type(item) is not bool:
                        return { 'error': 'an item in usb_3_file_io_pass must be boolean type'}

                data['usb_3_0_file_io_pass'] = 1 if usb_3_file_io_pass[0] else 0
                data['usb_3_1_file_io_pass'] = 1 if usb_3_file_io_pass[1] else 0
                data['usb_3_2_file_io_pass'] = 1 if usb_3_file_io_pass[2] else 0
                data['usb_3_3_file_io_pass'] = 1 if usb_3_file_io_pass[3] else 0
        
        if usb_2_bandwidth is not None:
            if type(usb_2_bandwidth) is not int:
                return { 'error': 'usb_2_bandwidth must be int type'}
            else:
                data['usb_2_bandwidth'] = usb_2_bandwidth
        
        if usb_2_communicate_pass is not None:
            if type(usb_2_communicate_pass) is not bool:
                return { 'error': 'usb_2_communicate_pass must be boolean type'}
            else:
                data['usb_2_communicate_pass'] = 1 if usb_2_communicate_pass else 0

        return await self._update_record(data=data)

    async def update_ethernet_results(self, ethernet_bandwidth, is_ping_pass):
        '''
        Usage)
        update_ethernet_results(
            ethernet_bandwidth=1000,
            is_ping_pass=True
        )
        '''

        if type(ethernet_bandwidth) is not int:
            return { 'error': 'ethernet_bandwidth must be int type' }
        if type(is_ping_pass) is not bool:
            return { 'error': 'is_ping_pass must be boolean type' }

        return await self._update_record(data={
            'ethernet_bandwidth': ethernet_bandwidth,
            'ethernet_ping_pass': 1 if is_ping_pass else 0,
        })

    async def update_hdmi_results(self, is_cec_pass=None, is_i2c_pass=None):
        '''
        Usage)
        update_hdmi_results(is_cec_pass=True, is_i2c_pass=True)
        '''

        data = {}
        if is_cec_pass is not None:
            if type(is_cec_pass) is not bool:
                return { 'error': 'is_cec_pass must be boolean type' }
            else:
                data['hdmi_cec_pass'] = 1 if is_cec_pass else 0

        if is_i2c_pass is not None:
            if type(is_i2c_pass) is not bool:
                return { 'error': 'is_i2c_pass must be boolean type' }
            else:
                data['hdmi_i2c_pass'] = 1 if is_i2c_pass else 0

        return await self._update_record(data=data)

    async def update_fan_results(self, is_pass):
        '''
        Usage)
        update_fan_results(is_pass=True)
        '''
        if type(is_pass) is not bool:
            return { 'error': 'is_pass must be boolean type' }

        return await self._update_record(data={
            'fan_pass': 1 if is_pass else 0,
        })

    async def update_gpio_results(self, is_pass, fail_nums=None):
        '''
        Usage)
        update_gpio_results(
            is_pass=True,
            fail_nums=[ 0, 1, 2, 3 ]
        )
        '''

        if type(is_pass) is not bool:
            return { 'error': 'is_pass must be boolean type' }

        if fail_nums is not None:
            if type(fail_nums) is not list:
                return { 'error': 'fail_nums must be list type' }

            for item in fail_nums:
                if type(item) is not int:
                    return { 'error': 'an item in fail_nums must be int type'}

        return await self._update_record(data={
            'gpio_pass': 1 if is_pass else 0,
            'gpio_fail': ','.join([ str(item) for item in fail_nums ]) if fail_nums is not None else '',
        })

    async def update_adc_results(self, is_pass, fail_nums=None):
        '''
        Usage)
        update_adc_results(
            is_pass=True,
            fail_nums=[ 0, 1, 2, 3 ]
        )
        '''

        if type(is_pass) is not bool:
            return { 'error': 'is_pass must be boolean type' }

        if fail_nums is not None:
            if type(fail_nums) is not list:
                return { 'error': 'fail_nums must be list type' }

            for item in fail_nums:
                if type(item) is not int:
                    return { 'error': 'an item in fail_nums must be int type'}

        return await self._update_record(data={
            'adc_pass': 1 if is_pass else 0,
            'adc_fail': ','.join([ str(item) for item in fail_nums ]) if fail_nums is not None else '',
        })

    async def update_led_ethernet_results(self, is_amber_pass, is_green_pass):
        '''
        Usage)
        update_led_ethernet_results(
            is_amber_pass=True,
            is_green_pass=True
        )
        '''

        if type(is_amber_pass) is not bool or type(is_green_pass) is not bool:
            return { 'error': 'is_{amber|green}_pass must be boolean type' }

        return await self._update_record(data={
            'led_ethernet_amber_pass': 1 if is_amber_pass else 0,
            'led_ethernet_green_pass': 1 if is_green_pass else 0,
        })

    async def update_led_power_system_results(self, is_power_pass=None, is_system_pass=None):
        '''
        Usage)
        update_led_power_system_results(
            is_power_pass=True,
            is_system_pass=True
        )
        '''

        data = {}
        if is_power_pass is not None:
            if type(is_power_pass) is not bool:
                return { 'error': 'is_power_pass must be boolean type' }
            else:
                data['led_power_pass'] = 1 if is_power_pass else 0
        
        if is_system_pass is not None:
            if type(is_system_pass) is not bool:
                return { 'error': 'is_system_pass must be boolean type' }
            else:
                data['led_system_pass'] = 1 if is_system_pass else 0

        return await self._update_record(data=data)

    async def update_ir_results(self, is_ir_pass):
        '''
        Usage)
        update_ir_results(is_ir_pass=True)
        '''

        if type(is_ir_pass) is not bool:
            return { 'error': 'is_ir_pass must be boolean type' }

        return await self._update_record(data={
            'ir_pass': 1 if is_ir_pass else 0
        })

    async def update_audio_results(self, is_audio_pass):
        '''
        Usage)
        update_audio_results(is_audio_pass=True)
        '''

        if type(is_audio_pass) is not bool:
            return { 'error': 'is_audio_pass must be boolean type' }

        return await self._update_record(data={
            'audio_pass': 1 if is_audio_pass else 0
        })

    async def update_switch_results(self, is_switch_pass):
        '''
        Usage)
        update_switch_results(is_switch_pass=True)
        '''

        if type(is_switch_pass) is not bool:
            return { 'error': 'is_switch_pass must be boolean type' }

        return await self._update_record(data={
            'slide_switch_pass': 1 if is_switch_pass else 0
        })

    async def update_iperf_udp_results(self, bandwidth, loss_rate):
        '''
        Usage)
        update_iperf_results(
            bandwidth=912.34,
            loss_rate=12.34
        )
        '''

        if not isinstance(bandwidth, (int, float)):
            return { 'error': 'bandwidth must be float type' }
        if not isinstance(loss_rate, (int, float)):
            return { 'error': 'loss_rate must be float type' }

        return await self._update_record(data={
            'iperf_rx_udp_bandwidth': round(bandwidth, 2),
            'iperf_rx_udp_loss_rate': round(loss_rate, 2),
        })

    async def update_rsync_results(self, transfer_speed):
        '''
        Usage)
        update_rsync_results(
            transfer_speed='90.01MB/s,100.02MB/s,110.03MB/s'
        )
        '''

        if type(transfer_speed) is not str:
            return { 'error': 'transfer_speed must be str type' }

        return await self._update_record(data={
            'rsync_transfer_speed': transfer_speed
        })

    async def request_mac_addr(self):
        if self.board is None:
            return

        response = await self._login_to_api_server()
        print(response)
        '''
        if 'error' in response:
            return { 'error': 'API login error: ' + response['error'] }
        '''

        async with aiohttp.ClientSession() as session:
            try:
                response = await session.post(
                    url=self.server_host + constants.API_POST_URL['request'],
                    headers={
                        'content-type': 'application/json',
                        'Authorization': 'Token ' + response['token']
                    },
                    ssl=False,
                    json={
                        'board': self.board
                    })
                response = await response.json()
            except Exception as e:
                print(e)
                return None

        if 'error' not in response:
            self.mac_addr = response['mac_addr']

            # For N2, ...
            if 'uuid_mac' in response:
                self.uuid_mac = response['uuid_mac']

            # The return value will be
            # only mac address (001e06300001) or
            # including uuid (00000000-...-001e06420001) string
            return self.uuid_mac or self.mac_addr
        else:
            print(f'API: Error: {response}')
            return None

    async def delete_assigned_sign(self):
        # If it obtains MAC address from the API server but it couldn't write
        # that, delete assigned sign that is written temporary from the record has
        # obtained MAC address on the database.
        if self.board is None or self.mac_addr is None:
            return

        response = await self._login_to_api_server()
        if 'error' in response:
            return { 'error': 'API login error: ' + response['error'] }

        async with aiohttp.ClientSession() as session:
            response = await session.post(
                url=self.server_host + constants.API_POST_URL['delete'],
                headers={
                    'content-type': 'application/json',
                    'Authorization': 'Token ' + response['token']
                },
                ssl=False,
                json={
                    'mac_addr': self.mac_addr,
                    'board': self.board
                })
            response = await response.json()

        if 'error' not in response:
            return response
        else:
            print(f'API: Error: {response}')
            return None

    async def get_criteria_for_board(self):
        response = await self._login_to_api_server()
        if 'error' in response:
            return { 'error': 'API login error: ' + response['error'] }

        async with aiohttp.ClientSession() as session:
            response = await session.post(
                url=self.server_host + constants.API_POST_URL['criteria'],
                headers={
                    'content-type': 'application/json',
                    'Authorization': 'Token ' + response['token']
                },
                ssl=False,
                json={
                    'board': self.board
                })
            response = await response.json()

        if 'error' not in response:
            return response
        else:
            print(f'API: Error: {response}')
            return None

    def clear(self, board):
        self.mac_addr = None
        self.uuid_mac = None
        self.api_auth_last_informed_expires_in = 0
        self.api_auth_last_token = ''
        self.board = board
